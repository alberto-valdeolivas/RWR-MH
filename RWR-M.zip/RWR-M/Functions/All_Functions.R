### Functions called from RWR-M.R

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
# GENERAL FUNCTIONS
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
# 1.- Package installation and load of libraries.
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####

install.packages.if.necessary <- function(CRAN.packages=c(), bioconductor.packages=c()) {
  if (length(bioconductor.packages) > 0) {
    source("http://bioconductor.org/biocLite.R")
  }
  for (p in bioconductor.packages) {
    if (!require(p, character.only=T)) {
      biocLite(p) 
      library(p, character.only=T)
    }
  }
  
  for (p in CRAN.packages) {	
    if (!require(p, character.only=T)) { 	
      install.packages(p) 	
      library(p, character.only=T)  	
    }	
  }
  
}

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
# 2.- We check the input parameters
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
check.parameters <- function(input_file,Nr_Networks){
  
  if (ncol(input_file) != 2) { stop("Incorrect Parameters Input File")}
  if (nrow(input_file) != 4) { stop("Incorrect Parameters Input File")}
  
  r <- as.numeric(input_file[1,2] )
  print(paste("Global restart probability:", r))
  if ((r > 1 || r <= 0)){ stop("Incorrect r, it must be between 0 and 1")}
  
  delta <- as.numeric(input_file[2,2] )
  print(paste("Inter-Layer Jump Probability:", delta))
  if ((delta > 1 || delta < 0)){ stop("Incorrect delta, it must be between 0 and 1")}
  
  tau <- as.numeric(unlist(strsplit(input_file[3,2],",")))
  print(paste("Layers Restart Probability: ", input_file[3,2]))
  if (sum(tau)/L != 1) {stop("Incorrect tau, the sum of its component divided by 3 must be 1")}
  
  k <- as.numeric(input_file[4,2] )
  print(paste("Number of Top results to be displayed in the output network:", k))
  if ((k > 200 || k <= 0)){ stop("Incorrect k, it must be between 0 and 200")}
  
  parameters <- list(r,delta,tau,k)
  names(parameters) <- c("r", "delta", "tau", "k")
  return(parameters)
}

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
# 3.- We check if the seed nodes are in our network.
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
check.seeds <- function(Seeds, All_proteins){
  
  Genes_Seeds_OK <- Seeds[which(Seeds %in% All_proteins)]
  Genes_Seeds_KO <- Seeds[which(!Seeds %in% All_proteins)]
  
  if (length(Genes_Seeds_OK) == 0) {
    stop("Seeds not found in our network")
  } else {
    if (length(Genes_Seeds_KO) > 0){
      print("Some Seed genes no present in the network: ")
      for (i in 1:length(Genes_Seeds_KO)){
        print(Genes_Seeds_KO[i])
      }
    }
    return(Genes_Seeds_OK)
  }
  
}


#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
# MULTIPLEX RELATED FUNCTIONS
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
# 4.- We read the different layers that integrate the multiplex network.
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####

read.layers <- function(vec_layers){
  
  ## "pre-allocate" an empty list of length size (Number of Layers)
  size <- length(vec_layers)
  Layers <- vector("list", size)
  
  ## We read the different Networks (Layers) of our Multiplex network. We also simplify the networks
  ## by removing possible self loops and possible multiple nodes.
  
  for (i in 1:size){
    if (vec_layers[i]=="PPI"){
      
      PPI_table <- read.table("Networks/PPI_2016-11-23.gr",sep=" ")
      PPI_Network <- graph.data.frame(PPI_table,directed=FALSE)
      PPI_Network <- igraph::simplify(PPI_Network, remove.multiple = TRUE, remove.loops = TRUE)
      
      Layers[[i]] <- PPI_Network
      names(Layers)[i] <- "PPI_NETWORK"
    } else {
      if (vec_layers[i]=="PATH"){
        
        Pathway_table <- read.table("Networks/AllPathways_2016-11-24.gr",sep=" ")
        Pathway_Network <- graph.data.frame(Pathway_table,directed=FALSE)
        Pathway_Network <- igraph::simplify(Pathway_Network, remove.multiple = TRUE, remove.loops = TRUE)
        
        Layers[[i]] <- Pathway_Network
        names(Layers)[i] <- "PATHWAY_NETWORK"
        
      } else {
        if (vec_layers[i]=="COEX"){
          Coex_table <- read.table("Networks/Co-Expression_2016-11-23.gr",sep=" ")
          Coex_Network <- graph.data.frame(Coex_table,directed=FALSE)
          Coex_Network <- igraph::simplify(Coex_Network, remove.multiple = TRUE, remove.loops = TRUE)
          
          Layers[[i]] <- Coex_Network
          names(Layers)[i] <- "COEXPRESION_NETWORK"
        } else {
          stop("Not correct Network Name")
        }
      } 
    }
  }
  ## We return a list containing an igraph object for each layer.
  return(Layers)
} 

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
# 5.- We generate a pool of nodes. We merge the nodes present in every layer.
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
pool.of.nodes <- function(Layers){
  
  ## We get the number of layers
  Nr_Layers <- length(Layers)
  
  ## We get the nodes of all the layers of the multiplex network. We save them into a vector.
  Node_Names_all <- character()
  for (i in 1:Nr_Layers) {
    Node_Names_Layer <- V(Layers[[i]])$name
    Node_Names_all <-c(Node_Names_all,Node_Names_Layer)
  }
  
  ## We remove duplicates.
  Node_Names_all <- unique(Node_Names_all)
  
  return(Node_Names_all)
} 

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
# 6.- From the pool of nodes we add the missing proteins to each layer as 
#     isolated nodes.
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
add.missing.nodes <- function (Layers,NodeNames) {
  
  ## We get the number of layers
  Nr_Layers <- length(Layers)
  
  ## We generate a new list of layers.
  Layers_New <- vector("list", Nr_Layers)
  
  ## We add to each layer the missing nodes of the total set of nodes, of the pool of nodes.
  for (i in 1:Nr_Layers){
    Node_Names_Layer <- V(Layers[[i]])$name
    Missing_Nodes <- NodeNames[which(!NodeNames %in% Node_Names_Layer)]
    Layers_New[[i]] <- add_vertices(Layers[[i]] ,length(Missing_Nodes), name=Missing_Nodes)
  }
  return(Layers_New)
}


#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
# 7.- We check the total number of nodes in every layer and we return it. 
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
Get.Number.Nodes <- function(Layers_Allnodes) {
  
  ## We get the number of layers
  Nr_Layers <- length(Layers_Allnodes)
  vector_check <- numeric(length = Nr_Layers)  
  
  for (i in 1:Nr_Layers){
    vector_check[i] <- vcount(Layers_Allnodes[[i]])  
  }
  
  if (all(vector_check == vector_check[1])){
    print("Number of nodes in every layer updated...")
    return(vector_check[1])  
  } else {
    stop("Not correct number of nodes in each Layer...")
  }
}


#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
# 8.- We check the total number of nodes in every layer and we return it. 
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####

get.supra.adj.multiplex <- function(Layers,delta,N){
  
  ## IDEM_MATRIX.
  Idem_Matrix <- Diagonal(N, x = 1)
  L <- length(Layers)
  
  SupraAdjacencyMatrix <- Matrix(0,ncol=N*L,nrow=N*L,sparse = TRUE)
  
  Col_Node_Names <- character()
  Row_Node_Names <- character()
  
  for (i in 1:L){
    Adjacency_Layer <-  as_adjacency_matrix(Layers[[i]],sparse = TRUE)
    
    ## We order the matrix by the node name. This way all the matrix will have the same. Additionally we include a label with the layer number for each node name.
    Adjacency_Layer <- Adjacency_Layer[order(rownames(Adjacency_Layer)),order(colnames(Adjacency_Layer))]
    Layer_Col_Names <- paste(colnames(Adjacency_Layer),i,sep="_")
    Layer_Row_Names <- paste(rownames(Adjacency_Layer),i,sep="_")
    Col_Node_Names <- c(Col_Node_Names,Layer_Col_Names)
    Row_Node_Names <- c(Row_Node_Names,Layer_Row_Names)
    
    ## We fill the diagonal blocks with the adjacencies matrix of each layer.
    Position_ini_row <- 1 + (i-1)*N
    Position_end_row <- N + (i-1)*N
    SupraAdjacencyMatrix[(Position_ini_row:Position_end_row),(Position_ini_row:Position_end_row)] <- (1-delta)*(Adjacency_Layer)
    
    ## We fill the off-diagonal blocks with the transition probability among layers.
    for (j in 1:L){
      Position_ini_col <- 1 + (j-1)*N
      Position_end_col <- N + (j-1)*N
      if (j != i){
        SupraAdjacencyMatrix[(Position_ini_row:Position_end_row),(Position_ini_col:Position_end_col)] <- (delta/(L-1))*Idem_Matrix
      }
    }
  }
  
  rownames(SupraAdjacencyMatrix) <- Row_Node_Names
  colnames(SupraAdjacencyMatrix) <- Col_Node_Names
  
  return(SupraAdjacencyMatrix)
}


#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
# 9.- GET THE SCORES OF THE DIFFERENT SEEDS
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####

get.seed.scores <- function(Genes,Number_Layers,tau) {
  
  Seeds_Genes_Scores <- numeric(length = length(Genes)*Number_Layers)
  Seed_Genes_Layer_Labeled <- character(length = length(Genes)*Number_Layers)
    
  Current_Gene_Labeled <- character()
  
  for (k in 1:L){
    Current_Gene_Labeled <- c(Current_Gene_Labeled,paste(Genes[k],k,sep="_",collapse = "") )
    for (j in 1:length(Genes)){
      Seed_Genes_Layer_Labeled[((k-1)*length(Genes))+ j] <- paste(Genes[j],k,sep="_",collapse = "") 
      Seeds_Genes_Scores[((k-1)*length(Genes))+ j] <- tau[k]/length(Genes)
    }
  }  
  Seeds_Score <- data.frame(Seeds_ID = Seed_Genes_Layer_Labeled,
                            Score = Seeds_Genes_Scores, stringsAsFactors = FALSE)
  return(Seeds_Score)
}  
  

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
# 10.- RANDOM WALK WITH RESTART
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####

Random_Walk_Restart <- function(Network_Matrix, r,SeedGenes ){
  
  ### We define the threshold and the number maximum of iterations for the randon walker.
  Threeshold <- 1e-10
  NetworkSize <- ncol(Network_Matrix)
  
  ### We initialize the variables to control the flux in the RW algo.
  residue <- 1
  iter <- 1
  
  #### We define the prox_vector(The vector we will move after the first RW iteration. We start from The seed. We have to take in account
  #### that the walker with restart in some of the Seed genes, depending on the score we gave in that file).
  prox_vector <- matrix(0,nrow = NetworkSize,ncol=1)
  
  prox_vector[which(colnames(Network_Matrix) %in% SeedGenes[,1])] <- (SeedGenes[,2])
  
  prox_vector  <- prox_vector/sum(prox_vector)
  restart_vector <-  prox_vector
  
  while(residue >= Threeshold){
    
    old_prox_vector <- prox_vector
    prox_vector <- (1-r)*(Network_Matrix %*% prox_vector) + r*restart_vector
    residue <- sqrt(sum((prox_vector-old_prox_vector)^2))
    iter <- iter + 1; 
  }
  return(prox_vector) 
} 

