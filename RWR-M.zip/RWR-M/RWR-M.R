#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
####                                                                       ####
#### RANDOM WALK WITH RESTART ON MULTIPLEX NETWORKS (RWR-M)                ####
####                                                                       ####
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
#### 1. NAME: RWR-M.R
#### 2. CONTENTS: SOURCE CODE TO EXECUTE RWR-M AS DESCRIBED IN THE PAPER:
####    "RANDOM WALK WITH RESTART ON MULTIPLEX AND HETEROGENEOUS NETWORKS" 
#### 3. CREATED: 20/01/2017 by Alberto Valdeolivas. 
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
#### 4. DESCRIPTION: This script performs Random walk with restart on a multiplex
####    network integrated by 3 layers: PPI, pathways and co-expression. 
####    To run the algorithm we need at least one seed gene. These seed genes
####    are given to the algorithm as an input file. Another input file should
####    contain the parameters needed to feed the method. Two output files are
####    generated: A file containing a sorted ranking of all the genes after
####    RWR-M and a network file containing the TOP genes and their interactions.
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
#### 5. INPUT PARAMETERS:
####   5.1.- The name of the file containing the nodes used as seeds in RWR-M
####   5.2.- The name of the file containing the different parameters of RWR-M    
####   5.3.- The name for the output files. The same name will be used for the 
####         ranking and for the network.
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
#### 6. OUTPUT FILES:
####   6.1.- A file with the sorted ranking of all the network genes. It
####         contains every HGNC gene symbol along with its RWR-M final score.
####         The file will be generated in the output_files folder with a name
####         related to the one given (point 5.3.)
####   6.2.- A file containing a network with the K top candidates genes. K is
####         specified by the user in an input file (point 5.2.)  
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
#### 7. EXAMPLE OF EXECUTION:
#### Rscript RWR-M.R Input_Files/Seeds_Example.txt Input_Files/Parameters_Example.txt Results_Example
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
#### SOURCE CODE:
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
rm(list=ls())
# setwd("/Users/AlbertoValdeolivas/Desktop/RWRMultiplex/RWR_Multiplex_Paper/RWR-M/")
Network_List <- c("PPI","PATH","COEX")
L <- length(Network_List)

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
## 1.- INSTALLING PACKAGES, LOADING LIBRARIES.
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####

### We install the needed packages.
CRAN.packages <- c("igraph","Matrix","Rcpp","dnet")
bioconductor.packages <- c("biomaRt","supraHex")

source("Functions/All_Functions.R")
source("Functions/create.multiplex.network.topResults.R") 

install.packages.if.necessary(CRAN.packages,bioconductor.packages)
sourceCpp("Functions/Geometric_Mean.cpp")

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
## 2.- READING INPUT FILES AND ARGUMENTS.
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
print("Reading arguments...")
args <- commandArgs(trailingOnly = TRUE)

# args <- c("Input_Files/Seeds_Example.txt", "Input_Files/Parameters_Example.txt", "Results_Example")
 
Seed_Genes <- read.csv(args[1],header=FALSE,sep="\t",dec=".",stringsAsFactors = FALSE)
Seed_Genes <- Seed_Genes$V1

Parameters_File <- read.csv(args[2],header=TRUE,sep="\t",dec=".",stringsAsFactors = FALSE)
Parameters <- check.parameters(Parameters_File,L )
  
Output_FileName_Ranking <- paste("Output_Files/",args[3],".txt",sep="",collapse = "")
Output_FileName_Network <- paste("Output_Files/",args[3],".gr",sep="",collapse = "")

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
## 3.- WE READ THE LAYERS OF OUR NETWORKS, WE GENERATE THE POOL OF NODES 
##     AND WE BUILD THE ADJACENCY MATRIX OF THE MULTIPLEX NETWORK.
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
print("Reading Multiplex Layers...")
List_Layers <- read.layers(Network_List)

### We get a pool of nodes (Nodes in any of the layers.) 
### Some nodes will belong to just some layers, while others will be on all of them.
pool_nodes <- pool.of.nodes(List_Layers)
pool_nodes_sorted <- sort(pool_nodes)

### We check that out Seed Genes are present in the network
Seed_Genes_OK <- check.seeds(Seed_Genes,pool_nodes_sorted)

### We add to each layer the missing nodes with no connections (no edges for them)
List_Layers_Allnodes <- add.missing.nodes(List_Layers, pool_nodes)

### We have to check that all the layers have the same number of Vertex. 
### We save N as the number of Nodes in all the layers (After adding those that were missing.)
N <- Get.Number.Nodes(List_Layers_Allnodes)

### We define the COST_MATRIX (see article, materials and methods.) The user can change this matrix
### to give more relevance to an specific layer.
D_Cost_JumpLayer <- matrix(1,nrow = L, ncol=L)
diag(D_Cost_JumpLayer) <- 0

### Adjacency matrix of the multiplex network.
print("Generating Multiplex Adjacency Matrix...")
SupraAdjacencyMatrix <- get.supra.adj.multiplex(List_Layers_Allnodes,Parameters$delta,D_Cost_JumpLayer,N)

### We perform the column normalizaiton on the adjacency matrix of the multiplex. 
print("Getting the Column Normalization...")
Total_Strengh_of_Nodes <-Matrix::colSums(SupraAdjacencyMatrix, na.rm = FALSE, dims = 1,sparseResult = FALSE)
Supra_Adj_Matrix_Normalized <-  t(t(SupraAdjacencyMatrix)/(Total_Strengh_of_Nodes))

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
## 4.- WE READ PREPARE THE SEEDS AND WE PERFORM THE RWR-M. WE WRITE 
##     THE OUTPUT FILE CONTAINING HGNC GENE SYMBOL AND THEIR RESULTING SCORES.
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####

tau <- Parameters$tau/L

Seeds_Score <- get.seed.scores(Seed_Genes_OK,L,tau)
print("Seeds score for RWR-M: ")
print(Seeds_Score)

print("Performing RWR-M....")
Random_Walk_Results <- Random_Walk_Restart(Supra_Adj_Matrix_Normalized,Parameters$r,Seeds_Score)

## To generate the ranking we just take the genes in the first layer; Then we calculate 
## the geometric mean taking in account results for each gene in every layer.
rank_global <- data.frame(GeneNames = character(length = N), Score = 0)
rank_global$GeneNames <- gsub("_1", "", row.names(Random_Walk_Results)[1:N])
rank_global$Score <- Geometric_Mean(as.vector(Random_Walk_Results[,1]),L,N)

## We sort the genes according to their score. 
Global_results <- rank_global[with(rank_global, order(-Score, GeneNames)), ]

### We remove the seed genes from the Ranking and we write the results.
Global_results_NoSeeds <- Global_results[which(!Global_results$GeneNames %in% Seed_Genes),]
write.table(Global_results_NoSeeds,Output_FileName_Ranking,sep="\t",row.names = FALSE, dec=".",quote=FALSE)

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
## 5.- NETWORK GENERATION FOR THE TOP K SELECTED GENES.
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####

Top_Results_Network <- create.multiplex.network.topResults(Network_List,Seed_Genes_OK,Global_results_NoSeeds$GeneNames[1:Parameters$k])

write.table(as_data_frame(Top_Results_Network, what = c("edges", "vertices", "both")), Output_FileName_Network, 
                        sep=" ", quote=FALSE,row.names=FALSE)
