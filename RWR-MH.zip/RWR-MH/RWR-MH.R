#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
####                                                                       ####
#### RANDOM WALK WITH RESTART ON MULTIPLEX AND HETEROGENEOUS NETWORKS      ####
####                        (RWR-MH)                                       ####
####                                                                       ####
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
#### 1. NAME: RWR-MH.R
#### 2. CONTENTS: SOURCE CODE TO EXECUTE RWR-MH AS DESCRIBED IN THE PAPER:
####    "RANDOM WALK WITH RESTART ON MULTIPLEX AND HETEROGENEOUS NETWORKS" 
#### 3. CREATED: 01/02/2017 by Alberto Valdeolivas. 
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
#### 4. DESCRIPTION: This script performs Random walk with restart on a multiplex
####    and heterogeneous graph integrated by a 3 layers gene interaction multiplex 
####    network: PPI, pathways and co-expression and a monoplex disease-disease 
####    similarity network.  
####    To run the algorithm we need at least one seed (gene or disease). These seeds 
####    are given to the algorithm as an input file. Another input file should
####    contain the parameters needed to feed the method. Three output files are
####    generated: A file containing a sorted ranking of all the genes after
####    RWR-MH, A file containing a sorted ranking of all the diseases and a network 
####    file containing the TOP genes and hte TOP diseases and their interactions.
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
#### 5. INPUT PARAMETERS:
####   5.1.- The name of the file containing the nodes used as seeds in RWR-MH
####   5.2.- The name of the file containing the different parameters of RWR-MH    
####   5.3.- The name for the output files. The same name will be used for the 
####         rankings and for the network.
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
#### 6. OUTPUT FILES:
####   6.1.- A file with the sorted ranking of all the network genes. It
####         contains every HGNC gene symbol along with its RWR-MH final score.
####         The file will be generated in the output_files folder with a name
####         related to the one given (point 5.3.)
####   6.2.- A file with the sorted ranking of all the network diseases It
####         contains every MIM ID disease along with its RWR-MH final score.
####         The file will be generated in the output_files folder with a name
####         related to the one given (point 5.3.)
####   6.3.- A file containing a network with the K top candidates genes and diseases. 
####         K is specified by the user in an input file (point 5.2.)  
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
#### 7. EXAMPLE OF EXECUTION:
#### Rscript RWR-MH.R Input_Files/Seeds_Example.txt Input_Files/Parameters_Example.txt Results_Example
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####


#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
#### SOURCE CODE:
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
rm(list=ls())
# setwd("/Users/AlbertoValdeolivas/Desktop/RWRMultiplex/RWR_Multiplex_Paper/RWR-MH/")
Network_List <- c("PPI","PATH","COEX")
L <- length(Network_List)


#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
## 1.- INSTALLING PACKAGES, LOADING LIBRARIES.
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####

### We install the needed packages.
CRAN.packages <- c("igraph","Matrix","Rcpp","dnet")
bioconductor.packages <- c("biomaRt","supraHex")

source("Functions/All_Functions.R")
source("Functions/CreateNetworks_TopMultiplexHeterogeneous.R") 

install.packages.if.necessary(CRAN.packages,bioconductor.packages)
sourceCpp("Functions/Geometric_Mean.cpp")


#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
## 2.- READING INPUT FILES AND ARGUMENTS.
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
print("Reading arguments...")
args <- commandArgs(trailingOnly = TRUE)

# args <- c("Input_Files/Seeds_Example.txt", "Input_Files/Parameters_Example.txt", "Results_Example")

All_Seeds <- read.csv(args[1],header=FALSE,sep="\t",dec=".",stringsAsFactors = FALSE)
All_Seeds <- All_Seeds$V1

Parameters_File <- read.csv(args[2],header=TRUE,sep="\t",dec=".",stringsAsFactors = FALSE)
Parameters <- check.parameters(Parameters_File,L )

Output_FileName_Ranking_Genes <- paste("Output_Files/",args[3],"_Genes",".txt",sep="",collapse = "")
Output_FileName_Ranking_Diseases <- paste("Output_Files/",args[3],"_Diseases",".txt",sep="",collapse = "")
Output_FileName_Network <- paste("Output_Files/",args[3],".gr",sep="",collapse = "")


#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
## 3.- WE READ THE LAYERS OF OUR MULTIPLEX NETWORKS, WE GENERATE THE POOL OF NODES 
##     AND WE BUILD THE ADJACENCY MATRIX OF THE MULTIPLEX NETWORK. (TRANSITION MATRIX)
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
print("Reading Multiplex Layers...")
List_Layers <- read.layers(Network_List)

### We get a pool of nodes (Nodes in any of the layers.) 
### Some nodes will belong to just some layers, while others will be on all of them.
pool_nodes <- pool.of.nodes(List_Layers)
pool_nodes_sorted <- sort(pool_nodes)

### We add to each layer the missing nodes with no connections (no edges for them)
List_Layers_Allnodes <- add.missing.nodes(List_Layers, pool_nodes)

### We have to check that all the layers have the same number of Vertex. 
### We save N as the number of Nodes in all the layers (After adding those that were missing.)
N <- Get.Number.Nodes(List_Layers_Allnodes)

### Adjacency matrix of the multiplex network. (Transition Matrix for the multiplex system.)
print("Generating Multiplex Adjacency Matrix...")
SupraAdjacencyMatrix <- get.supra.adj.multiplex(List_Layers_Allnodes,Parameters$delta,N)

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
## 4.- WE GENERATE THE HETEROGENEOUS NETWORK.  
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
## 4.1.- FIRST, WE READ THE DISEASE-DISEASE SIMILARITY NETWORK.
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
print("Reading the disease-similarity network...")

## Reading Disease-Disease similarity Network
Disease_table <- read.table("Networks/DiseaseSimilarity_2016-12-06.gr",sep=" ")
Disease_Network <- graph.data.frame(Disease_table,directed=FALSE)
Disease_Network <- igraph::simplify(Disease_Network, remove.multiple = TRUE, remove.loops = TRUE)
AdjMatrix_Diseases <- as_adjacency_matrix(Disease_Network,sparse = TRUE)

## Number of diseases in the network. 
M <- nrow(AdjMatrix_Diseases)

### Now, that we have the diseases and the proteins of our system we can check the nodes.
print("Checking Seed nodes...")
Seed_File_list <- check.seeds(All_Seeds,pool_nodes,rownames(AdjMatrix_Diseases))


#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
## 4.2.- GENERATION OF THE BIPARTITE GRAPH. 
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####

## We get Gene-disease relations downloaded from Biomart.
print("Reading Ensemble file with Gene-disease relations from OMIM...")
Gene_Phenotype_relation <- get.disease.gene.relations(pool_nodes)

print("Generating Bipartite Graph...")

Bipartite_matrix_and_report <- get.bipartite.graph(pool_nodes_sorted, colnames(AdjMatrix_Diseases), Gene_Phenotype_relation,N,M)
Bipartite_matrix <- Bipartite_matrix_and_report[[1]]
Error_log <- Bipartite_matrix_and_report[[2]]

## We expand the biparite graph to fit the multiplex dimensions.
## The biparti matrix has now (N x M)  dimensions. However we need it to have NL x M
## The genes in all the layers have to point to the diseases

print("Adapting Bipartite Graph to the Multiplex...")
SupraBipartiteMatrix <- expand.bipartite.graph(N,L,M,Bipartite_matrix)


#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
## 4.3.- From the supra-adjacency matrix of the Multiplex system, the adjacency 
##       matrix of the disease-disease Similarity network and the expandend bipartite 
##       graph we calculate a transition matrix according to Li and Patra (2010)
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
print("Transforming from adjacency matrices to transition matrix...")

#### Transition Matrix for the inter-subnetworks links

Transition_Protein_Disease <- get.transition.protein.disease(N,L,M,SupraBipartiteMatrix,Parameters$lambda)
Transition_Disease_Protein <- get.transition.disease.protein(N,L,M,SupraBipartiteMatrix,Parameters$lambda)

#### Transition Matrix for the intra-subnetworks links
# Transition_Multiplex_Network <- get.transition.multiplex(N,L,lambda,SupraAdjacencyMatrix,SupraBipartiteMatrix)
Transition_Multiplex_Network <- get.transition.multiplex(N,L,Parameters$lambda,SupraAdjacencyMatrix,SupraBipartiteMatrix)
Transition_Disease_Network <- get.transition.disease(M,Parameters$lambda,AdjMatrix_Diseases,SupraBipartiteMatrix)

### We generate the global transiction matrix and we return it.
Transition_Multiplex_Heterogeneous_Matrix_1 <- cbind(Transition_Multiplex_Network, Transition_Protein_Disease)
Transition_Multiplex_Heterogeneous_Matrix_2 <- cbind(Transition_Disease_Protein, Transition_Disease_Network)
Transition_Multiplex_Heterogeneous_Matrix <- rbind(Transition_Multiplex_Heterogeneous_Matrix_1,Transition_Multiplex_Heterogeneous_Matrix_2)

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
## 5.- WE PREPARE THE SEEDS SCORES AND WE PERFORM THE RWR-MH. WE WRITE 
##     THE OUTPUT FILE CONTAINING HGNC GENE SYMBOL AND THEIR RESULTING SCORES.
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####

Gene_Seeds <- Seed_File_list[[1]]
Disease_Seeds <- Seed_File_list[[2]]

tau <- Parameters$tau/L

# We compute the restart probability of each seed, based on eta and tau.
Seeds_Score <- get.seed.scores(Gene_Seeds,Disease_Seeds,Parameters$eta,L,tau)
print(Seeds_Score)

print("Performing Random Walk...")

# We perform the Walks on the multiplex-heterogeneous network.
Random_Walk_Results <- Random_Walk_Restart(Transition_Multiplex_Heterogeneous_Matrix,Parameters$r,Seeds_Score)

### We remove the seed genes from the ranking, we sort by score and we write the results.
final_rank_proteins <- rank_proteins(N, L,Random_Walk_Results,Gene_Seeds)
final_rank_diseases <- rank_diseases(N,L,M,Random_Walk_Results,Disease_Seeds)

write.table(final_rank_proteins,Output_FileName_Ranking_Genes,sep="\t",row.names = FALSE, dec=".",quote=FALSE)
write.table(final_rank_diseases,Output_FileName_Ranking_Diseases,sep="\t",row.names = FALSE, dec=".",quote=FALSE)

#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
## 6.- NETWORK GENERATION FOR THE TOP K SELECTED GENES AND DISEASES.
#### #### #### #### #### #### #### #### #### #### #### #### #### #### #### ####
print("Creating Network file with the top candidates...")
Top_Results_Network <- CreateNetworks_TopMultiplexHeterogeneous(Network_List,c(Gene_Seeds,Disease_Seeds),
                       final_rank_proteins$GeneNames[1:Parameters$k],final_rank_diseases$DiseaseID[1:Parameters$k])

write.table(as_data_frame(Top_Results_Network, what = c("edges", "vertices", "both")), Output_FileName_Network, 
            sep=" ", quote=FALSE,row.names=FALSE)

